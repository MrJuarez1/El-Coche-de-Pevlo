/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test1.Controlador;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class EsValido extends Conexion{
    public boolean IsValido(String facultad,String pass){
        try {
            Statement st=  con.createStatement();
             ResultSet rs= null;
            String consulta;
            System.out.println(facultad+" "+pass);
            consulta="Select * from app.Facultad where  nombre='"+facultad+"' and  password = '"+pass+"'";
            rs= st.executeQuery(consulta);
            return rs.next();
        } catch (SQLException ex) {
            Logger.getLogger(EsValido.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
        return false;
    }
}
