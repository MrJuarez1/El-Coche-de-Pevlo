/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test1.Controlador;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fernando
 */
public class Consultas extends Conexion{
    
    public Consultas(){
        super();
    }
    public  HashMap<String,HashSet<String>> GetMenu(String facultad) throws SQLException{
        
        Statement st=  con.createStatement();
        ResultSet rs= null;
        String consulta;
        HashMap<String,HashSet<String>> res= new HashMap<>();
        res.put("Primeros", new HashSet<String>());
        res.put("Segundos", new HashSet<String>());
        res.put("Postres", new HashSet<String>());
        HashSet<String> aux;
        String tipo;
        consulta = "select *"
                + " from app.plato "
                + " where Id_p "
                +                   "IN( select Id_P"
                +                       " from app.pertenece"
                +                       " where Id_F =( select Id_F from app.facultad where Nombre='"+facultad+"'))";
        rs = st.executeQuery(consulta);
        while(rs.next()){
            tipo=rs.getString("Tipo");
            if(tipo.equals("Primero")){
                aux= res.get("Primeros");
                aux.add(rs.getString("Nombre"));
                res.put("Primeros", aux);
            }else if(tipo.equals("Segundo")){
                aux= res.get("Segundos");
                aux.add(rs.getString("Nombre"));
                res.put("Segundos", aux);
            }else {
                aux= res.get("Postres");
                aux.add(rs.getString("Nombre"));
                res.put("Postres", aux);
            }
        }
        return res;
    }
    
    public static void main(String[] args){
        Consultas con = new Consultas();
        try {
            System.out.println(con.GetMenu("Informatica").toString());
        } catch (SQLException ex) {
            Logger.getLogger(Consultas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
