/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test1.Controlador;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author fernando
 */
public class AddPl extends Conexion{
    public boolean Add(String tipo,String plato,String nombre,boolean del){
        try{
            boolean aux=false;
             Statement st=  con.createStatement();
             ResultSet rs = null;
             String consulta;
             consulta= "select max(id_p)\"Max\" from app.plato";
        rs= st.executeQuery(consulta);
        int id=1;
        while(rs.next()){
             id= rs.getInt("Max")+1;
             System.out.println(id);
        }
        st= con.createStatement();
        if(!del)
            consulta="insert into app.plato values("+id+",'"+plato+"','"+tipo+"')";
        else
            consulta="delete from app.pertenece where id_p in (select id_p from app.plato where nombre='"+plato+"')";
        st.executeUpdate(consulta);
        if(!del){    
            consulta="select app.FACULTAD.ID_F\"fac\" from app.FACULTAD where nombre like '"+nombre+"'";
            st= con.createStatement();
            rs=st.executeQuery(consulta);
            int id_f=-1;
            while(rs.next()){
                id_f = rs.getInt("fac");
            }
            st=con.createStatement();
            consulta="insert into app.pertenece values("+id_f+","+id+")";
            st.executeUpdate(consulta);
        }else{
            consulta="delete from app.Plato where Nombre='"+plato+"'";
            st= con.createStatement();
            st.executeUpdate(consulta);
        }
                
        return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    
    
    }
    public static void main(String[] args){
        AddPl aux = new AddPl();
        System.out.println(Boolean.toString(aux.Add("Segundo", "Helado", "Informatica", false)));
    }
}
