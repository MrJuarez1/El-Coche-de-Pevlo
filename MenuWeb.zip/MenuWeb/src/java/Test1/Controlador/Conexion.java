/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test1.Controlador;


import java.sql.DriverManager;
import java.sql.*;
//import org.apache.jasper.tagplugins.jstl.core.Catch;
import java.sql.SQLException;



/**
 *
 * @author fernando
 */

public class Conexion {
    
    
    public Connection con;
    
    public Conexion(){
        try{
            Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/MenuDB","root", "123");
            System.out.println("Estoy conectadooo");
        }catch(Exception e){
            System.out.println(e);
            
        }
    }
    
    public static void main(String[] args){
        Conexion con = new Conexion();
    }
}
